﻿using contentModeratorApi.Globals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ApiContentModerator
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ImagenContent : ContentPage
    {
        public ImagenContent()
        {
            InitializeComponent();
        
        }

        private async void cargar_Clicked(object sender, EventArgs e)
        {

            images.Source = url.Text;
        }

        private void comprobar_Clicked(object sender, EventArgs e)
        {

            string apropiado;

            String valor = ModerateImageAsync(url.Text).Result;


            resumen.Text = "Resumen Contenido:";

            String[] result = valor.Split(',');
            if (result[1].Contains("false"))
            {
                apropiado = "Contenido Apropiado";
            }
            else
            {
                apropiado = " Contenido No apropiado ";
            }

            valorAdulto.Text = valor;
            resumen.Text += apropiado;
        }


        public static async Task<String> ModerateImageAsync(string ImageUrl)
        {

            string ResponseJSON = string.Empty;
            string Body = $"{{\"DataRepresentation\":\"URL\",\"Value\":\"{ImageUrl}\"}}";

            Console.WriteLine("Moderating image: " + ImageUrl);

            HttpResponseMessage response =
                Helpers.CallAPI(Globals.APIURI_IMAGEN, Globals.CONTENTMODERATOR_APIKEY, Globals.CallType.POST,
                                                   "Ocp-Apim-Subscription-Key", "application/json",
                                                   string.Empty, Body);

            String responseBody = "";
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                responseBody = response.Content.ReadAsStringAsync().Result;

            }

            return responseBody;
        }


    }
}