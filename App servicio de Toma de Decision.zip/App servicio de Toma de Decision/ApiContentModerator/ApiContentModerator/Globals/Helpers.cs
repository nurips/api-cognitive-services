﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Http;
using System.Net.Http.Headers;

namespace contentModeratorApi.Globals
{
    class Helpers
    {
      
      
        public static HttpResponseMessage CallAPI(string Uri, string Key, Globals.CallType Type,
                                                    string AuthenticationLabel, string ContentType,
                                                    string UrlParameter, string Body)
        {

            if (!String.IsNullOrEmpty(UrlParameter))
            {
                Uri += "?" + UrlParameter;
            }

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(Uri);

            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add(
            new MediaTypeWithQualityHeaderValue(ContentType));

            client.DefaultRequestHeaders.Add(AuthenticationLabel, Key);

            HttpResponseMessage response = null;

            if (Type == Globals.CallType.POST)
            {
                response = client.PostAsync(Uri, new StringContent(
                                   Body, System.Text.Encoding.UTF8, ContentType)).Result;
            }
            else if (Type == Globals.CallType.GET)
            {
                response = client.GetAsync(Uri).Result;
            }

            return response;
        }
    }


}

