﻿using System;
using System.Collections.Generic;
using System.Text;

namespace contentModeratorApi.Globals
{
    class Globals
    {

        public enum CallType { POST, GET };

        public const int CALLSTATUSOK = 200;
        public const int CALLVOLUMEEXCEEDED = 403;
        public const int CALLRATEEXCEEDED = 429;
        public const int CALLWAITTIME = 1000;

        //Content Moderator Key 
        public const string CONTENTMODERATOR_APIKEY = Secrets.CONTENTMODERATOR_APIKEY;


        // All Uris
        public const string APIURI_IMAGEN = "https://pruebacontent.cognitiveservices.azure.com/contentmoderator/moderate/v1.0/ProcessImage/Evaluate";
        public const string  APIURI_TEXT= "https://pruebacontent.cognitiveservices.azure.com/contentmoderator/moderate/v1.0/ProcessText/Screen";
    }

}


