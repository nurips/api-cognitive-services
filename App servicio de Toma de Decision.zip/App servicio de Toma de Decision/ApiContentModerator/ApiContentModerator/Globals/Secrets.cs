﻿using System;
using System.Collections.Generic;
using System.Text;

namespace contentModeratorApi.Globals
{
    class Secrets
    {
        //Content Moderator Key 
        public const string CONTENTMODERATOR_APIKEY = "0e40efe04268434da0430bb04d4b69a5";
    }
}
