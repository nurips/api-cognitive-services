﻿using contentModeratorApi.Globals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ApiContentModerator
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TextContent : ContentPage
    {
        public TextContent()
        {
            InitializeComponent();
        }

        private void cargar_Clicked(object sender, EventArgs e)
        {
         

           string valo = ModerateText(palabra.Text);

            valorjson.Text = valo;

        }

        public static string ModerateText(string Text)
        {
            string ResponseJSON = string.Empty;
            string ParamsEng = "&classify=true&PII=true&autocorrect=true&";

            Console.WriteLine("Moderating text: " + Text);

            HttpResponseMessage response =
                Helpers.CallAPI(Globals.APIURI_TEXT, Globals.CONTENTMODERATOR_APIKEY, Globals.CallType.POST,
                                                   "Ocp-Apim-Subscription-Key", "text/plain",
                                                   ParamsEng, Text);

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                Console.WriteLine("Saving moderation response.");

                ResponseJSON = response.Content.ReadAsStringAsync().Result;

            
            }

            return ResponseJSON;
        }
    }
}