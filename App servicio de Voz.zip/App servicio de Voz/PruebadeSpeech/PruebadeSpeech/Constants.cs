﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PruebadeSpeech
{
    public static class Constants
    {
       /* public static readonly string AuthenticationTokenEndpoint = "https://api.cognitive.microsofttranslator.com/sts/v1.0";*/


        public static string CognitiveServicesApiKey = "af483fc3f8614ae5b288f2fac9931a30";
        public static string CognitiveServicesRegion = "westeurope";

        /*public static readonly string TextTranslatorApiKey = "50075bb8715746b281644a78b0cbd0ee";
        public static readonly string TextTranslatorEndpoint = "https://api.cognitive.microsofttranslator.com/";*/
    }
}
