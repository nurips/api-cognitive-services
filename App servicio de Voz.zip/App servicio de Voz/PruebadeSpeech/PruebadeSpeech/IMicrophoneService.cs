﻿using System.Threading.Tasks;

namespace PruebadeSpeech
{
    public  interface IMicrophoneService
    {
        Task<bool> GetPermissionAsync();
        void OnRequestPermissionResult(bool isGranted);
    }
}