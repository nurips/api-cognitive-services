﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.IO;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Newtonsoft.Json;
using Microsoft.CSharp;

using System.Threading.Tasks;
namespace Traductor
{
    public partial class MainPage : ContentPage
    {
        const string COGNITIVE_SERVICES_KEY = "50075bb8715746b281644a78b0cbd0ee";
        public static readonly string TEXT_TRANSLATION_API_ENDPOINT = "https://api.cognitive.microsofttranslator.com/";
        private string[] languageCodes;
        List<String> idiomas = new List<string>();

        private SortedDictionary<string, string> languageCodesAndTitles =
        new SortedDictionary<string, string>(Comparer<string>.Create((a, b) => string.Compare(a, b, true)));
        public MainPage()
        {
            InitializeComponent();
            Iniciar();
          
        }



        public void Iniciar()
        {

            GetLanguagesForTranslate();
            // Populate drop-downs with values from GetLanguagesForTranslate
            PopulateLanguageMenus();
        }






        private void GetLanguagesForTranslate()
        {
            // Send request to get supported language codes
            String uri_endpoint_languages = TEXT_TRANSLATION_API_ENDPOINT + "languages?api-version=3.0";
            string uri = String.Format(uri_endpoint_languages, "languages") + "&scope=translation";
            WebRequest WebRequest = WebRequest.Create(uri);
            WebRequest.Headers.Add("Accept-Language", "en");
            WebResponse response = null;
            try
            {
                // Read and parse the JSON response
                response = WebRequest.GetResponse();
            }catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            using (var reader = new StreamReader(response.GetResponseStream(), UnicodeEncoding.UTF8))
            {
                var result = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, Dictionary<string, string>>>>(reader.ReadToEnd());
                var languages = result["translation"];

                languageCodes = languages.Keys.ToArray();
                foreach (var kv in languages)
                {
                    languageCodesAndTitles.Add(kv.Value["name"], kv.Key);
                }
            }
        }


        private void PopulateLanguageMenus()
        {
            
             foreach (string menuItem in languageCodesAndTitles.Keys)
             {
                 Filtro.Items.Add(menuItem);
                 segundo.Items.Add(menuItem);
             }
          


            // Set default languages
            Filtro.SelectedItem = "Spanish";
            segundo.SelectedItem = "English";
        }
        

        
    
        private async void  tra_Clicked(object sender, EventArgs e)
        {
            string textToTranslate = traducir.Text.Trim();

            string fromLanguage = Filtro.SelectedItem.ToString();
            string fromLanguageCode;

                fromLanguageCode = languageCodesAndTitles[fromLanguage];

            string toLanguageCode = languageCodesAndTitles[segundo.SelectedItem.ToString()];

            // send HTTP request to perform the translation
            string route = "/translate?api-version=3.0";
            string url = TEXT_TRANSLATION_API_ENDPOINT+route;
            string endpoint = string.Format(url, "translate");
            string uri = string.Format(endpoint + "&from={0}&to={1}", fromLanguageCode, toLanguageCode);

           object[] body = new object[] { new { Text = textToTranslate } };
            var requestBody = JsonConvert.SerializeObject(body);

            using (var client = new HttpClient())
            using (var request = new HttpRequestMessage())
            {
                request.Method = HttpMethod.Post;
                request.RequestUri = new Uri(uri);
                request.Content = new StringContent(requestBody, Encoding.UTF8, "application/json");
                request.Headers.Add("Ocp-Apim-Subscription-Key", COGNITIVE_SERVICES_KEY);
                request.Headers.Add("Ocp-Apim-Subscription-Region", "westeurope");
              

                var response = await client.SendAsync(request);
                var responseBody = await response.Content.ReadAsStringAsync();

                var result = JsonConvert.DeserializeObject<List<Dictionary<string, List<Dictionary<string, string>>>>>(responseBody);
                var translation = result[0]["translations"][0]["text"];





                // Update the translation field
                traducido.Text = translation;
            }







        }
        // NOTE:
        // In the following sections, we'll add code below this.



        
    }
}
