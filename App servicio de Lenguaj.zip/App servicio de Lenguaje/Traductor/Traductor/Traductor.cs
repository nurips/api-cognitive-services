﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Traductor
{
    class Traductor
    {
        private Datos[] translations;

        internal Datos[] Translations { get => translations; set => translations = value; }
    }
    class Datos
    {
        private String text;
        private String to;
        public string Text1 { get => text; set => text = value; }
        public string To { get => to; set => to = value; }
    }
}
